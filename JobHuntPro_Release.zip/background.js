// JobHunt Pro - Background Service Worker
const API_BASE = 'https://jhfguf.pythonanywhere.com';
const ALARM_NAME = 'statsUpdate';

// ── Install ──
chrome.runtime.onInstalled.addListener(() => {
  console.log('[JobHunt Pro] Extension installed');
  
  // Set up periodic stats update
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: 5 });
  
  // Open welcome page on install
  chrome.tabs.create({ url: `${API_BASE}?utm_source=chrome-extension` });
});

// ── Alarm handler ──
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === ALARM_NAME) {
    await updateStats();
  }
});

// ── Message handlers ──
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getStats') {
    chrome.storage.local.get(['stats'], (data) => {
      sendResponse(data.stats || getDefaultStats());
    });
    return true; // async response
  }
  
  if (request.action === 'updateStats') {
    updateStats().then(sendResponse);
    return true;
  }

  if (request.action === 'openDashboard') {
    chrome.tabs.create({ url: API_BASE + '/user-dashboard' });
    sendResponse({ success: true });
  }

  if (request.action === 'CDP_CLICK') {
    const tabId = sender.tab.id;
    const { x, y } = request;
    
    // Attach debugger, send mouse events, detach
    chrome.debugger.attach({ tabId: tabId }, '1.3', () => {
      if (chrome.runtime.lastError) {
        console.error('Debugger attach failed:', chrome.runtime.lastError.message);
        sendResponse({ success: false, error: chrome.runtime.lastError.message });
        return;
      }
      
      chrome.debugger.sendCommand({ tabId: tabId }, 'Input.dispatchMouseEvent', {
        type: 'mousePressed',
        x: x,
        y: y,
        button: 'left',
        clickCount: 1
      }, () => {
        chrome.debugger.sendCommand({ tabId: tabId }, 'Input.dispatchMouseEvent', {
          type: 'mouseReleased',
          x: x,
          y: y,
          button: 'left',
          clickCount: 1
        }, () => {
          chrome.debugger.detach({ tabId: tabId });
          sendResponse({ success: true });
        });
      });
    });
    return true; // async response
  }

  // ── Command Center: Sensor Payload Handlers ──
  
  if (request.type === 'REPORT_STATE') {
    console.log(`[Command Center] Frame ${sender.tab.id} reported state:`, request.status, 'Active for:', request.timeActive, 'ms');
    if (request.timeActive > 45000) {
      console.warn(`[Command Center] Smart Skip Triggered for frame ${sender.tab.id}`);
      chrome.tabs.sendMessage(sender.tab.id, { type: 'SMART_SKIP', reason: 'timeout_45s' });
    }
    sendResponse({ success: true });
    return;
  }

  if (request.type === 'CAPTCHA_DETECTED') {
    console.warn(`[Command Center] 🚨 RED ALERT: CAPTCHA in frame ${sender.tab.id} (${request.frameUrl})`);
    // Broadcast GLOBAL_HALT to all frames in the tab
    chrome.tabs.sendMessage(sender.tab.id, { type: 'GLOBAL_HALT', reason: 'captcha_intervention' });
    sendResponse({ success: true });
    return;
  }

  if (request.type === 'DOM_SCAN_RESULT') {
    console.log(`[Command Center] Swarm routing data from frame ${sender.tab.id}:`, request.unansweredQuestions, request.clickables.length, 'clickables');
    // Here the Command Center would securely talk to the DeepSeek API using the user's JWT
    // For now, we mock the Swarm response
    sendResponse({ success: true, message: 'Swarm processing...' });
    return;
  }
});

// ── Stats management ──
async function updateStats() {
  try {
    const data = await chrome.storage.local.get([STORAGE_KEY]);
    if (!data[STORAGE_KEY]) return getDefaultStats();

    const response = await fetch(`${API_BASE}/api/user/stats`, {
      headers: { 'Authorization': `Bearer ${data[STORAGE_KEY].token}` }
    });
    
    if (response.ok) {
      const json = await response.json();
      const stats = {
        apps: json.total_applications || 0,
        matchRate: json.match_rate || 0,
        coverLetters: json.cover_letters || 0,
        timeSaved: Math.round((json.applications_sent || 0) * 5 / 60)
      };
      await chrome.storage.local.set({ stats });
      return stats;
    }
  } catch (e) {
    console.error('[JobHunt Pro] Stats update failed:', e);
  }
  return getDefaultStats();
}

function getDefaultStats() {
  return { apps: 0, matchRate: 0, coverLetters: 0, timeSaved: 0 };
}

const STORAGE_KEY = 'jobhunt_pro_auth';
