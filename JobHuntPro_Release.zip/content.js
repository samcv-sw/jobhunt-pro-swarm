// JobHunt Pro - Content Script
// Injected into LinkedIn, Indeed, Glassdoor, Bayt, ZipRecruiter, etc.
(function() {
  'use strict';

  const API_BASE = 'https://jhfguf.pythonanywhere.com';
  let userData = null;

  // ── Init ──
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    switch (request.action) {
      case 'autoApply': handleAutoApply(sendResponse); return true;
      case 'fillForm': handleFillForm(sendResponse); return true;
      case 'generateCoverLetter': handleGenerateCoverLetter(sendResponse); return true;
    }
  });

  // ── Inject floating button ──
  function injectFloatingButton() {
    if (document.getElementById('jh-pro-floating-btn')) return;
    
    const btn = document.createElement('div');
    btn.id = 'jh-pro-floating-btn';
    btn.innerHTML = '⚡ Auto-Apply (Pro)';
    btn.style.cssText = `
      position: fixed; bottom: 20px; right: 20px; z-index: 999999;
      background: linear-gradient(135deg, #00f0ff, #0088ff);
      color: #000; font-weight: 700; padding: 12px 20px;
      border-radius: 25px; cursor: pointer; font-size: 14px;
      box-shadow: 0 4px 20px rgba(0,240,255,0.3);
      transition: transform 0.2s;
    `;
    btn.addEventListener('mouseenter', () => btn.style.transform = 'scale(1.05)');
    btn.addEventListener('mouseleave', () => btn.style.transform = 'scale(1)');
    btn.addEventListener('click', handleAutoApply);
    document.body.appendChild(btn);
  }

  // ── Inject Bulk Apply Button (Robot Mode) ──
  function injectBulkButton() {
    const isSearchPage = window.location.href.includes('/search') || 
                         window.location.href.includes('q=') || 
                         window.location.href.includes('/jobs');
                         
    if (!isSearchPage || document.getElementById('jh-pro-bulk-btn')) return;

    const btn = document.createElement('div');
    btn.id = 'jh-pro-bulk-btn';
    btn.innerHTML = '🤖 Bulk Auto-Apply (100+)';
    btn.style.cssText = `
      position: fixed; bottom: 80px; right: 20px; z-index: 999999;
      background: linear-gradient(135deg, #ff007f, #7000ff);
      color: #fff; font-weight: 700; padding: 12px 20px;
      border-radius: 25px; cursor: pointer; font-size: 14px;
      box-shadow: 0 4px 20px rgba(112,0,255,0.4);
      transition: transform 0.2s;
    `;
    btn.addEventListener('mouseenter', () => btn.style.transform = 'scale(1.05)');
    btn.addEventListener('mouseleave', () => btn.style.transform = 'scale(1)');
    btn.addEventListener('click', startBulkApplyRobot);
    document.body.appendChild(btn);
  }

  // ── Bulk Apply Robot Loop (Infinite) ──
  // ── Iframe State Variables ──
  let isRobotRunning = false;
  let activeFrameTime = 0;
  let stateInterval = null;

  // ── Command Center Messaging (Sensors) ──
  function startSensorReporting() {
    if (stateInterval) clearInterval(stateInterval);
    stateInterval = setInterval(() => {
      if (!isRobotRunning) return;
      activeFrameTime += 5000;
      chrome.runtime.sendMessage({
        type: 'REPORT_STATE',
        frameUrl: window.location.href,
        status: 'applying',
        timeActive: activeFrameTime
      });
    }, 5000);
  }

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'GLOBAL_HALT') {
      console.warn('🚨 GLOBAL HALT received from Command Center');
      isRobotRunning = false;
      if (document.getElementById('jh-robot-progress')) {
         document.getElementById('jh-robot-progress').innerHTML = `🛑 Robot Halted globally (CAPTCHA/Intervention)`;
      }
    }
    
    if (request.type === 'SMART_SKIP') {
      console.warn('⏩ SMART SKIP received: Application taking too long');
      // Logic to close modal or move to next job
      activeFrameTime = 0;
      // Depending on site, you might click 'cancel' or 'close' here
    }
  });

  async function startBulkApplyRobot() {
    if (isRobotRunning) {
      showToast('🤖 Robot is already running!');
      return;
    }
    isRobotRunning = true;
    showToast('🤖 Infinite Robot Mode Activated! Scanning for jobs...');
    
    let appliedCount = 0;
    const storageResult = await chrome.storage.local.get(['processedJobs']);
    const processedJobs = new Set(storageResult.processedJobs || []);
    
    // Create progress UI
    const progressUI = document.createElement('div');
    progressUI.id = 'jh-pro-progress';
    progressUI.style.cssText = `
      position: fixed; top: 20px; left: 50%; transform: translateX(-50%); z-index: 999999;
      background: #000; color: #00f0ff; border: 1px solid #00f0ff;
      padding: 10px 20px; border-radius: 8px; font-weight: bold;
      cursor: pointer;
    `;
    progressUI.title = "Click to stop Robot";
    progressUI.addEventListener('click', () => {
      isRobotRunning = false;
      progressUI.innerHTML = '🛑 Robot stopping...';
    });
    document.body.appendChild(progressUI);

    while (isRobotRunning) {
      const url = window.location.href;
      let jobCards = [];
      
      if (url.includes('linkedin.com')) jobCards = document.querySelectorAll('.job-card-container');
      else if (url.includes('indeed.com')) jobCards = document.querySelectorAll('.job_seen_beacon, .tapItem');
      else if (url.includes('glassdoor.com')) jobCards = document.querySelectorAll('.react-job-listing');
      else if (url.includes('seek.com.au')) jobCards = document.querySelectorAll('[data-automation="normalJob"]');
      else if (url.includes('stepstone.de') || url.includes('stepstone.com')) jobCards = document.querySelectorAll('.res-1h3m1h4');
      else if (url.includes('dice.com')) jobCards = document.querySelectorAll('.card');
      else if (url.includes('xing.com')) jobCards = document.querySelectorAll('a[data-x-track="job-listing"]');
      else if (url.includes('naukri.com')) jobCards = document.querySelectorAll('.jobTuple, article.jobTuple');
      else if (url.includes('jooble.org')) jobCards = document.querySelectorAll('article, div[data-test-name="jobCard"]');
      else if (url.includes('upwork.com')) jobCards = document.querySelectorAll('section.up-card-section');
      else jobCards = document.querySelectorAll('li, .job, .card'); // fallback

      // Filter unprocessed cards
      const unprocessedCards = Array.from(jobCards).filter(card => {
        const jobId = card.innerText.trim().slice(0, 100);
        return !processedJobs.has(jobId);
      });
      
      if (unprocessedCards.length > 0) {
        for (let i = 0; i < unprocessedCards.length; i++) {
          if (!isRobotRunning) break;
          
          // CAPTCHA Pause & Ping Protocol
          const pageText = document.body.innerText.toLowerCase();
          const hasCaptcha = pageText.includes('verify you are human') || 
                             pageText.includes('checking your browser') ||
                             document.querySelector('.cf-turnstile') || 
                             document.querySelector('iframe[src*="captcha"]');
                             
          if (hasCaptcha) {
            console.warn('🚨 CAPTCHA DETECTED. Pausing execution.');
            
            // Play alert sound
            try {
              const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
              const oscillator = audioCtx.createOscillator();
              const gainNode = audioCtx.createGain();
              oscillator.connect(gainNode);
              gainNode.connect(audioCtx.destination);
              oscillator.type = 'square';
              oscillator.frequency.value = 400; // Hz
              oscillator.start();
              setTimeout(() => oscillator.stop(), 500);
            } catch (e) {}

            // Show UI overlay and wait
            await new Promise(resolve => {
              const modal = document.createElement('div');
              modal.style.cssText = `
                position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
                background: rgba(200,0,0,0.9); backdrop-filter: blur(5px);
                display: flex; flex-direction: column; justify-content: center; align-items: center; z-index: 9999999;
                font-family: system-ui, sans-serif;
              `;
              modal.innerHTML = `
                <div style="font-size: 64px; margin-bottom: 20px;">🚨</div>
                <h1 style="color: white; font-weight: bold; margin-bottom: 10px; font-size: 32px;">CAPTCHA DETECTED</h1>
                <p style="color: #ffd700; font-size: 18px; margin-bottom: 30px;">The job board requested a security check due to high application volume.</p>
                <p style="color: white; margin-bottom: 30px; font-size: 16px;">Please solve the CAPTCHA manually behind this overlay.</p>
                <button id="resume-robot-btn" style="background: white; color: #c80000; font-size: 20px; font-weight: bold; padding: 15px 40px; border: none; border-radius: 8px; cursor: pointer; box-shadow: 0 4px 15px rgba(0,0,0,0.3); z-index: 99999999;">
                  I solved it - Resume Robot ▶
                </button>
              `;
              document.body.appendChild(modal);

              document.getElementById('resume-robot-btn').addEventListener('click', () => {
                modal.remove();
                resolve();
              });
            });
          }
          
          const card = unprocessedCards[i];
          const jobId = card.innerText.trim().slice(0, 100);
          processedJobs.add(jobId);
          chrome.storage.local.set({ processedJobs: Array.from(processedJobs) });
          
          progressUI.innerHTML = `🤖 Robot applying... (${appliedCount} total applied)<br><small style="font-size:10px;color:#aaa">Click here to stop</small>`;
          
          // Scroll to card and click to load details via CDP
          card.scrollIntoView({ behavior: 'smooth', block: 'center' });
          const clickable = card.querySelector('a') || card;
          if (clickable) {
            const rect = clickable.getBoundingClientRect();
            const x = Math.round(rect.left + rect.width / 2);
            const y = Math.round(rect.top + rect.height / 2);
            
            // Send CDP click message to background script
            chrome.runtime.sendMessage({ action: 'CDP_CLICK', x: x, y: y });
          }
          
          // Wait for content to load (anti-ban delay)
          await new Promise(r => setTimeout(r, Math.random() * 2000 + 1500));
          
          // Extract the job currently showing on screen
          const jobData = extractJobFromPage();
          if (jobData && jobData.title) {
            try {
              const response = await fetch(`${API_BASE}/api/job/analyze-and-apply`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(jobData),
              });
              if (response.status === 403 || response.status === 401) {
                 progressUI.remove();
                 showToast('🔒 Premium Feature: Upgrade to unlock Bulk Robot Mode!');
                 setTimeout(() => window.open(`${API_BASE}/pricing`, '_blank'), 1500);
                 isRobotRunning = false;
                 return;
              }
              if (response.ok) appliedCount++;
            } catch (e) {
              console.error("Bulk apply failed for one job", e);
            }
          }
        }
      } else {
        // No new cards found. Try to scroll down to force lazy load.
        window.scrollBy(0, 1000);
        
        // Also scroll the inner container if we are on linkedin
        const innerScroll = document.querySelector('.jobs-search-results-list');
        if (innerScroll) innerScroll.scrollBy(0, 1000);
        
        await new Promise(r => setTimeout(r, 2000));
        
        // Re-check cards after scrolling
        let newCardsCount = 0;
        if (url.includes('linkedin.com')) newCardsCount = document.querySelectorAll('.job-card-container').length;
        else if (url.includes('indeed.com')) newCardsCount = document.querySelectorAll('.job_seen_beacon, .tapItem').length;
        else newCardsCount = document.querySelectorAll('li, .job, .card').length;
        
        if (newCardsCount <= processedJobs.size) {
          // Scrolling didn't yield new cards. Try Pagination (Next Page).
          progressUI.innerHTML = `🔄 Turning to next page...`;
          
          let nextBtn = null;
          
          // Use Semantic DOM Router to find the "Next" button
          const targetCoords = await semanticDOMRouter('next_page');
          
          if (targetCoords) {
            chrome.runtime.sendMessage({ action: 'CDP_CLICK', x: targetCoords.x, y: targetCoords.y });
            processedJobs.clear(); // Clear so it can process new page elements if they reuse DOM nodes
            await new Promise(r => setTimeout(r, 4000)); // wait for next page to load
          } else {
             // We hit the absolute end
             isRobotRunning = false;
             progressUI.innerHTML = `✅ Robot Finished! Exhausted all jobs. Total applied: ${appliedCount}`;
             setTimeout(() => progressUI.remove(), 4000);
             return;
          }
        }
      }
    }
    
    // If manually stopped
    progressUI.innerHTML = `🛑 Robot Stopped manually. Total applied: ${appliedCount}`;
    setTimeout(() => progressUI.remove(), 3000);
  }

  // ── Auto-Apply ──
  async function handleAutoApply(sendResponse) {
    try {
      // Extract job details from page
      const jobData = extractJobFromPage();
      if (!jobData) {
        showToast('❌ No job detected on this page');
        if (sendResponse) sendResponse({ success: false, error: 'No job detected' });
        return;
      }

      showToast('🤖 AI analyzing job and applying...');

      // Send job to API for AI processing
      const response = await fetch(`${API_BASE}/api/job/analyze-and-apply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(jobData),
      });

      if (response.status === 403 || response.status === 401) {
        // Handle Free User / Unauthorized - Show Tease & Reveal Hook
        showToast('🎯 Application ready, but requires Pro!');
        
        // Inject Tease & Reveal Modal
        const modal = document.createElement('div');
        modal.id = 'jh-pro-tease-modal';
        modal.style.cssText = `
          position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
          background: rgba(0,0,0,0.85); backdrop-filter: blur(5px);
          display: flex; justify-content: center; align-items: center; z-index: 9999999;
          font-family: system-ui, -apple-system, sans-serif;
        `;
        
        modal.innerHTML = `
          <div style="background: #111; border: 1px solid #333; border-radius: 16px; padding: 32px; max-width: 500px; width: 90%; text-align: center; box-shadow: 0 20px 50px rgba(0,240,255,0.1);">
            <div style="font-size: 48px; margin-bottom: 16px;">🎯</div>
            <h2 style="color: #fff; margin: 0 0 8px 0; font-size: 24px;">Perfect Match Found: <span style="color: #00f0ff;">98%</span></h2>
            <p style="color: #aaa; margin: 0 0 24px 0; font-size: 15px;">We've already generated the perfect tailored cover letter and resume summary for this position. It's waiting for you.</p>
            
            <div style="background: #1a1a1a; padding: 20px; border-radius: 8px; text-align: left; position: relative; overflow: hidden; margin-bottom: 24px; border: 1px solid #333;">
              <div style="color: #ccc; font-size: 14px; line-height: 1.6; filter: blur(4px); user-select: none;">
                Dear Hiring Manager,<br><br>
                Based on the requirements for the ${jobData.title || 'position'} role at ${jobData.company || 'your company'}, my background aligns perfectly with your needs. I have extensive experience driving results and exceeding expectations in similar environments...
                <br><br>My technical skills match 98% of the job description, specifically in the areas you highlighted as critical...
              </div>
              <div style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: linear-gradient(to bottom, transparent, #111); display: flex; align-items: flex-end; justify-content: center; padding-bottom: 20px;">
                <span style="background: rgba(0,240,255,0.1); color: #00f0ff; padding: 6px 16px; border-radius: 20px; font-size: 13px; font-weight: bold; border: 1px solid rgba(0,240,255,0.3);">🔒 Content Encrypted</span>
              </div>
            </div>
            
            <button id="jh-go-pro-btn" style="background: linear-gradient(135deg, #00f0ff, #0080ff); color: #000; border: none; padding: 16px 32px; font-size: 16px; font-weight: bold; border-radius: 8px; cursor: pointer; width: 100%; transition: transform 0.2s;">
              Unlock & Auto-Apply Instantly 🚀
            </button>
            <p id="jh-close-tease" style="color: #666; margin-top: 16px; font-size: 13px; cursor: pointer; text-decoration: underline;">Maybe later</p>
          </div>
        `;
        
        document.body.appendChild(modal);
        
        document.getElementById('jh-go-pro-btn').addEventListener('click', () => {
          window.open(`${API_BASE}/pricing`, '_blank');
          modal.remove();
        });
        
        document.getElementById('jh-close-tease').addEventListener('click', () => {
          modal.remove();
        });

        if (sendResponse) sendResponse({ success: false, error: 'upgrade_required' });
        return;
      }

      if (response.ok) {
        const result = await response.json();
        
        // Auto-fill form if on application page
        if (detectApplicationForm()) {
          await fillApplicationForm(result.candidate_data);
        }
        
        showToast(`✅ Applied! Match score: ${result.match_score}%`);
        if (sendResponse) sendResponse({ success: true, score: result.match_score });
      } else {
        showToast('❌ Application failed. Open dashboard to apply.');
        if (sendResponse) sendResponse({ success: false });
      }
    } catch (e) {
      showToast('⚠️ Error or not connected. Click extension icon to login.');
      if (sendResponse) sendResponse({ success: false, error: e.message });
    }
  }

  // ── Auto-Fill Form ──
  async function handleFillForm(sendResponse) {
    try {
      const jobData = extractJobFromPage();
      const response = await fetch(`${API_BASE}/api/job/analyze`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(jobData),
      });
      
      if (response.ok) {
        const result = await response.json();
        await fillApplicationForm(result.candidate_data);
        showToast('✅ Form auto-filled!');
        if (sendResponse) sendResponse({ success: true });
      }
    } catch (e) {
      if (sendResponse) sendResponse({ success: false });
    }
  }

  // ── Generate Cover Letter ──
  async function handleGenerateCoverLetter(sendResponse) {
    try {
      const jobData = extractJobFromPage();
      const response = await fetch(`${API_BASE}/api/free-tools/cover-letter`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          job_title: jobData.title,
          company: jobData.company,
          skills: jobData.skills || [],
        }),
      });
      
      if (response.ok) {
        const result = await response.json();
        showToast('✅ Cover letter copied to clipboard!');
        if (sendResponse) sendResponse({ success: true, letter: result.data.body });
      }
    } catch (e) {
      if (sendResponse) sendResponse({ success: false });
    }
  }

  // ── Extract job from page ──
  function extractJobFromPage() {
    const url = window.location.href;
    let job = { url, source: 'unknown', title: '', company: '', description: '', skills: [] };

    // LinkedIn
    if (url.includes('linkedin.com/jobs')) {
      job.source = 'linkedin';
      job.title = document.querySelector('.job-details-jobs-unified-top-card__job-title')?.textContent?.trim() ||
                  document.querySelector('h1')?.textContent?.trim() || '';
      job.company = document.querySelector('.job-details-jobs-unified-top-card__company-name')?.textContent?.trim() || '';
      job.description = document.querySelector('.jobs-description__content')?.textContent?.trim() || '';
      job.skills = [...document.querySelectorAll('.job-details-how-you-match__skills-item')].map(el => el.textContent.trim());
    }
    // Indeed
    else if (url.includes('indeed.com')) {
      job.source = 'indeed';
      job.title = document.querySelector('.jobsearch-JobInfoHeader-title')?.textContent?.trim() || '';
      job.company = document.querySelector('[data-company-name]')?.textContent?.trim() || '';
      job.description = document.getElementById('jobDescriptionText')?.textContent?.trim() || '';
    }
    // Glassdoor
    else if (url.includes('glassdoor.com')) {
      job.source = 'glassdoor';
      job.title = document.querySelector('.job-title')?.textContent?.trim() || '';
      job.company = document.querySelector('.employer-name')?.textContent?.trim() || '';
      job.description = document.querySelector('.jobDescriptionContent')?.textContent?.trim() || '';
    }
    // Bayt
    else if (url.includes('bayt.com')) {
      job.source = 'bayt';
      job.title = document.querySelector('.is-spaced')?.textContent?.trim() || '';
      job.company = document.querySelector('.t-small.u-mid')?.textContent?.trim() || '';
      job.description = document.querySelector('.card-content')?.textContent?.trim() || '';
    }
    // ZipRecruiter
    else if (url.includes('ziprecruiter.com')) {
      job.source = 'ziprecruiter';
      job.title = document.querySelector('.job_title')?.textContent?.trim() || '';
      job.company = document.querySelector('.company_name')?.textContent?.trim() || '';
      job.description = document.querySelector('.job_description')?.textContent?.trim() || '';
    }
    // Wellfound
    else if (url.includes('wellfound.com')) {
      job.source = 'wellfound';
      job.title = document.querySelector('h1')?.textContent?.trim() || '';
      job.company = document.querySelector('h2')?.textContent?.trim() || '';
      job.description = document.querySelector('.styles_description__xxxx')?.textContent?.trim() || '';
    }
    // Dice
    else if (url.includes('dice.com')) {
      job.source = 'dice';
      job.title = document.querySelector('h1.jobTitle')?.textContent?.trim() || '';
      job.company = document.querySelector('a[data-cy="companyNameLink"]')?.textContent?.trim() || '';
      job.description = document.getElementById('jobdescSec')?.textContent?.trim() || '';
    }
    // Seek
    else if (url.includes('seek.com.au')) {
      job.source = 'seek';
      job.title = document.querySelector('[data-automation="job-detail-title"]')?.textContent?.trim() || '';
      job.company = document.querySelector('[data-automation="advertiser-name"]')?.textContent?.trim() || '';
      job.description = document.querySelector('[data-automation="jobAdDetails"]')?.textContent?.trim() || '';
    }
    // StepStone
    else if (url.includes('stepstone.de') || url.includes('stepstone.com')) {
      job.source = 'stepstone';
      job.title = document.querySelector('h1.listing-title')?.textContent?.trim() || '';
      job.company = document.querySelector('span.listing-company')?.textContent?.trim() || '';
      job.description = document.querySelector('.listing-content')?.textContent?.trim() || '';
    }
    // WeWorkRemotely
    else if (url.includes('weworkremotely.com')) {
      job.source = 'weworkremotely';
      job.title = document.querySelector('.listing-header-container h1')?.textContent?.trim() || '';
      job.company = document.querySelector('.listing-header-container h2 a')?.textContent?.trim() || '';
      job.description = document.querySelector('.listing-container')?.textContent?.trim() || '';
    }
    // Xing
    else if (url.includes('xing.com')) {
      job.source = 'xing';
      job.title = document.querySelector('h1')?.textContent?.trim() || '';
      job.company = document.querySelector('[class*="company"]')?.textContent?.trim() || '';
      job.description = document.querySelector('[class*="description"]')?.textContent?.trim() || '';
    }
    // Naukri
    else if (url.includes('naukri.com')) {
      job.source = 'naukri';
      job.title = document.querySelector('.jd-header-title')?.textContent?.trim() || '';
      job.company = document.querySelector('.jd-header-comp-name a')?.textContent?.trim() || '';
      job.description = document.querySelector('.job-desc')?.textContent?.trim() || '';
    }
    // Jooble
    else if (url.includes('jooble.org')) {
      job.source = 'jooble';
      job.title = document.querySelector('h1')?.textContent?.trim() || '';
      job.company = document.querySelector('[class*="company"]')?.textContent?.trim() || '';
      job.description = document.querySelector('[class*="desc"]')?.textContent?.trim() || '';
    }
    // Upwork
    else if (url.includes('upwork.com')) {
      job.source = 'upwork';
      job.title = document.querySelector('h1')?.textContent?.trim() || '';
      job.company = 'Upwork Client';
      job.description = document.querySelector('.job-description')?.textContent?.trim() || '';
    }

    return job.title ? job : null;
  }

  // ── Detect application form ──
  function detectApplicationForm() {
    return !!(
      document.querySelector('input[name="name"]') ||
      document.querySelector('input[name="firstName"]') ||
      document.querySelector('input[name="email"]') ||
      document.querySelector('input[type="file"]') ||
      document.querySelector('textarea')
    );
  }

  // ── Semantic DOM Router ──
  async function semanticDOMRouter(intent) {
    const clickables = Array.from(document.querySelectorAll('button, a, input[type="submit"], input[type="button"]')).filter(el => {
      const rect = el.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && el.innerText.trim().length > 0;
    });

    const elementsData = clickables.map((el, index) => {
      const rect = el.getBoundingClientRect();
      return {
        id: index,
        tag: el.tagName,
        text: el.innerText.trim().substring(0, 50),
        x: Math.round(rect.left + rect.width / 2),
        y: Math.round(rect.top + rect.height / 2)
      };
    });

    if (elementsData.length === 0) return null;

    showToast(`🧠 Micro-Swarm scanning DOM for ${intent}...`);
    try {
      const response = await fetch(`${API_BASE}/api/job/semantic-router`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ intent: intent, elements: elementsData })
      });
      
      if (response.ok) {
        const res = await response.json();
        if (res.target_x && res.target_y) {
          return { x: res.target_x, y: res.target_y };
        }
      }
    } catch (e) {
      console.log('[JobHunt Pro] Semantic Router API failed, using fallback regex');
    }
    
    // Fallback heuristic
    let fallbackRegex = intent === 'next_page' ? /next|continue|>/i : /apply|submit|continue/i;
    let target = elementsData.find(el => fallbackRegex.test(el.text));
    return target ? { x: target.x, y: target.y } : null;
  }

  // ── Memory Vault: Auto-Answering Questions ──
  async function askSwarmOrVault(questionText, cvData) {
    const data = await chrome.storage.local.get(['questionVault']);
    const vault = data.questionVault || {};
    
    // 1. Check local vault memory
    if (vault[questionText]) {
      console.log('[JobHunt Pro] Found answer in Memory Vault:', questionText);
      return vault[questionText];
    }
    
    // 2. Not in vault, ask the DeepSeek Swarm API
    showToast('🧠 Swarm analyzing new question...');
    try {
      const response = await fetch(`${API_BASE}/api/job/ask-swarm`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: questionText, cv: cvData })
      });
      if (response.ok) {
        const res = await response.json();
        // 3. Save to vault for next time
        if (res.answer) {
          vault[questionText] = res.answer;
          await chrome.storage.local.set({ questionVault: vault });
          return res.answer;
        }
      }
    } catch (e) {
      console.log('[JobHunt Pro] Swarm API failed, using fallback');
    }
    
    // Fallback default answer
    const fallback = "Yes / 5 years"; // Basic fallback
    vault[questionText] = fallback;
    await chrome.storage.local.set({ questionVault: vault });
    return fallback;
  }

  // ── Ghost Interaction Protocol (Human Typing Simulation) ──
  async function simulateHumanTyping(inputElement, text) {
    inputElement.focus();
    inputElement.value = '';
    for (let i = 0; i < text.length; i++) {
      inputElement.value += text[i];
      inputElement.dispatchEvent(new Event('input', { bubbles: true }));
      // Random delay between 30ms and 80ms to simulate human typing speed
      await new Promise(r => setTimeout(r, Math.random() * 50 + 30));
    }
    inputElement.dispatchEvent(new Event('change', { bubbles: true }));
    inputElement.blur();
  }

  // ── Fill application form ──
  async function fillApplicationForm(data) {
    if (!data) return;

    const fields = {
      'name': data.name || '',
      'firstName': data.first_name || '',
      'lastName': data.last_name || '',
      'email': data.email || '',
      'phone': data.phone || '',
      'location': data.location || '',
      'linkedin': data.linkedin_url || '',
      'website': data.website || '',
      'summary': data.summary || '',
    };

    // Fill text fields with human simulation
    for (const [key, value] of Object.entries(fields)) {
      const input = document.querySelector(`input[name="${key}"], input[id*="${key}"], textarea[name="${key}"], textarea[id*="${key}"]`);
      if (input && value) {
        await simulateHumanTyping(input, value);
      }
    }

    // Handle custom questions with Memory Vault
    const allInputs = document.querySelectorAll('input[type="text"], textarea');
    for (const input of allInputs) {
      if (input.value) continue; // skip already filled
      
      const label = input.labels?.[0] || input.closest('label') || input.parentElement?.previousElementSibling;
      if (label && label.innerText) {
        const questionText = label.innerText.trim();
        if (questionText.length > 5) {
          const answer = await askSwarmOrVault(questionText, data);
          if (answer) {
            await simulateHumanTyping(input, answer);
          }
        }
      }
    }

    // Try to attach resume file if upload input exists
    const fileInput = document.querySelector('input[type="file"]');
    if (fileInput && data.cv_url) {
      try {
        const response = await fetch(data.cv_url);
        const blob = await response.blob();
        const file = new File([blob], 'resume.pdf', { type: 'application/pdf' });
        const dt = new DataTransfer();
        dt.items.add(file);
        fileInput.files = dt.files;
        fileInput.dispatchEvent(new Event('change', { bubbles: true }));
      } catch (e) {
        console.log('[JobHunt Pro] Could not attach resume file');
      }
    }
  }

  // ── Toast UI ──
  function showToast(message) {
    let toast = document.getElementById('jh-pro-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'jh-pro-toast';
      toast.style.cssText = `
        position: fixed; top: 20px; right: 20px; z-index: 9999999;
        background: #111; color: #fff; padding: 12px 24px;
        border-radius: 8px; border-left: 4px solid #00f0ff;
        font-family: system-ui, sans-serif; font-size: 14px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.5);
        transition: opacity 0.3s; opacity: 0;
      `;
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.style.opacity = '1';
    
    if (window.jhToastTimeout) clearTimeout(window.jhToastTimeout);
    window.jhToastTimeout = setTimeout(() => {
      toast.style.opacity = '0';
    }, 4000);
  }

  // ── Add toast animation ──
  const style = document.createElement('style');
  style.textContent = `
    @keyframes jhToastIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
  `;
  document.head.appendChild(style);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectFloatingButton);
  } else {
    injectFloatingButton();
  }
})();
